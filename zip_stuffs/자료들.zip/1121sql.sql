create Table RRenroll (
enroll_id int auto_increment primary key,
user_id  varchar(50) not null, 
course_id int not null,
enroll_date datetime default current_timestamp,

constraint fk_enroll_user
foreign key (user_id)references user(user_id),
constraint fk_enroll_course
foreign key(course_id) references RRcourse(course_id)
);

