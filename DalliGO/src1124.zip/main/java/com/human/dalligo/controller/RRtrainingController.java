package com.human.dalligo.controller;



import java.util.List;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.human.dalligo.service.RRtrainingService;
import com.human.dalligo.vo.RRcourseVO;
import com.human.dalligo.vo.RRtrainerVO;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;



@RequiredArgsConstructor
@Controller
public class RRtrainingController {
	
 private final  RRtrainingService trainingservice;
	
	
	
  @GetMapping("/")
  public String getTrain(Model model) {
	  
	  List<RRcourseVO> course = trainingservice.selectList();
	  model.addAttribute("course", course);	  
      return "/training/trainingBoard";
  }  

  @GetMapping("/login")
  public String getlogin() {
      return "/training/login";
  }
  
  @GetMapping("/trainerRegister")
  public String registerview() {
      return "/training/trainerRegister";
  }
  
  @GetMapping("/tutorials")
  public String gettutorials() {
      return "/training/tutorials";
  }
  
  @GetMapping("/course")
  public String getcourse() {
      return "/training/course";
  } 
  
  @PostMapping("/course")
  public String postcourse(@ModelAttribute RRcourseVO coursevo, HttpSession session) {
	// 세션에서 로그인한 trainerId 저장한거 가져오기 (getAttribute)
	  String trId = (String) session.getAttribute("trainerId");
	  if(trId==null) { //trainerId가 없으면 다시 로그인으로
		  return "redirect:/login";
	  }
	  //VO에다 trainerId 셋팅
	  coursevo.setTrainerId(trId);  
	  
	  //DB에 저장
	  trainingservice.insert(coursevo);      
	  return "redirect:/";
  }  
  
   

 
  
  @PostMapping("/trainerRegister")
  public String getRegistrer(@ModelAttribute RRtrainerVO trainervo) {
	  trainingservice.insert(trainervo);	  
	  return "redirect:/login";
  } 
  
  @PostMapping("/login")
  public String postlogin(@ModelAttribute RRtrainerVO trainervo, HttpSession session) {  
	  
	  RRtrainerVO loginvo = trainingservice.select(trainervo);
	  if(loginvo!=null) { //로그인성공-->세션에 trainerId 저장 (setAttribute)
		  session.setAttribute("trainerId", trainervo.getTrainerId());
		  return "redirect:/course";
	  }else {
		  return "redirect:/login?error";
	  }

     
  }
  
  
  
}
