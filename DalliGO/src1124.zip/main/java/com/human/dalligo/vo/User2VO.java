package com.human.dalligo.vo;

import lombok.Data;

@Data
public class User2VO {
	private Integer id;
	private String userId ;
	private String password;
	private String name;
	private String nick_name;
	private String address;
	private String phone;
	private String is_admin;

}
